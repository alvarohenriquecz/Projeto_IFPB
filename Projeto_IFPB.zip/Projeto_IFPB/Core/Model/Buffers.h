#pragma once

struct OutputBuffer {
  GLuint dataBuffer = 0;
  GLuint stateObject = 0;
};
